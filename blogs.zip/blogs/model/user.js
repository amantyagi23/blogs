const User = {

}

module.exports = User