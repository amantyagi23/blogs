

const express = require("express");


const app = express();

app.use(express.json());


app.post("/post",(request,response)=>{
    console.log(request.body);
    return response.send("in post method")
})

app.post("/apipost",(request,response)=>{
    const {name}= request.body;
    console.log(name);
    return response.send("in post method")
})

app.put("/put",(request,response)=>{
    request.body
    return response.send("in put method")
})

app.delete("/delete",(request,response)=>{
    return response.send("in delete method")
})

app.get("/api",(request, response)=>{
console.log("hello"); 
    // console.log("req",request);

    // console.log("response",response);
    return response.send(`
    <h1>Hello world</h1>`)
});


// app.post();
// app.put();
// app.delete()

app.listen(5000,(error)=>{
    if(error){
        console.log("Error Occurs",error)
    }
    else{
        console.log("Server started")
    }
})